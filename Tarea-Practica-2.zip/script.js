<script>
  // JavaScript para cambiar el fondo al hacer clic en el botón
  document.getElementById("cambiarFondoButton").addEventListener("click", function () {
      // Cambia el fondo de la página actual al color deseado
      document.body.style.backgroundColor = "#ff6600";
  });
</script>






